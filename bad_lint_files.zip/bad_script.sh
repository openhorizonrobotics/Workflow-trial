#!/bin/bash
echo "Hello world"
ls -l | grep "txt"
if [ -f file ]; then echo Found; fi
