function foo() {
console.log('Missing indent')
}
